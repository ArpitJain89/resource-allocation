import React from "react";
import { Link, withRouter } from "react-router-dom";
import "./Employee.css";
import { Redirect, Route } from "react-router";
import Employee from "./component/Employee";

const resourceData = require("../assets/employees.json");
// import { Redirect } from "react-router";

class EmployeeList extends React.Component {
  projects = [];
  projectId;
  SelectedProjectName = "";
  selectedProjectId = 0;

  constructor(props) {
    super(props);
    this.state = {
      selectedProjectEmployees: [],
      projectName: "",
      navigate: false,
      referrer: null,
      message: "",
      myData: [],
      id: 0
    };

    this.onChangeOfProjectSelect = this.onChangeOfProjectSelect.bind(this);
    this.onClickOfShowAllocation = this.onClickOfShowAllocation.bind(this);
    this.callbackFunction = this.callbackFunction.bind(this);
    // this.goToChild = this.goToChild.bind(this);
  }
  /**
   * call method for get data from session storage
   */
  // goToChild() {
  //   console.log("method");

  //   <Redirect
  //     to={{
  //       pathname: "/employee/Child",
  //       state: { name: "fromParent" }
  //     }}
  //   />;
  // }

  componentWillMount() {
    this.addDataToSessionStoarge();
  }

  /**
   *
   * @param {*} event - Event
   */
  onChangeOfProjectSelect(event) {
    this.selectedProjectId = parseInt(event.target.value, 10);
    sessionStorage.setItem("projectId", this.selectedProjectId);
    sessionStorage.setItem("selectedProjectId", this.selectedProjectId);
    const selectedProjects = this.projects.filter(
      project => project.id === this.selectedProjectId
    );
    this.SelectedProjectName = selectedProjects[0].name;
    this.selectedProjectEmployees = selectedProjects.length
      ? selectedProjects[0].employees
      : {};
    this.selectedProjectEmployees = this.selectedProjectEmployees.filter(
      emp => emp.projectAllocation > 0
    );
  }

  /**
   * This is used to show selected employee
   */
  onClickOfShowAllocation() {
    this.upDateState(this.selectedProjectEmployees, this.SelectedProjectName);
  }

  /**
   *
   * @param {*} employeess -employeess is nothing but selected employee
   * @param {*} projectName -projectName is nothing but selected projectName
   */
  upDateState(employeess, projectName) {
    this.setState({
      selectedProjectEmployees: employeess,
      projectName: projectName
    });
  }
  /**
   * This is used to add data in session storage
   */
  addDataToSessionStoarge() {
    if (
      !(
        sessionStorage.getItem("employees") &&
        sessionStorage.getItem("projects")
      )
    ) {
      sessionStorage.setItem(
        "employees",
        JSON.stringify(resourceData.employees)
      );
      sessionStorage.setItem("projects", JSON.stringify(resourceData.projects));
    } else {
      resourceData.projects = JSON.parse(sessionStorage.getItem("projects"));

      if (sessionStorage.getItem("projectId") != null) {
        this.selectedProjectId = sessionStorage.getItem("projectId");
        const selectedProjects = resourceData.projects.filter(
          project => project.id === parseInt(this.selectedProjectId)
        );
        this.selectedProjectEmployees = selectedProjects.length
          ? selectedProjects[0].employees
          : {};
        console.log(
          "this.selectedProjectEmployees",
          this.selectedProjectEmployees
        );
        this.selectedProjectEmployees = this.selectedProjectEmployees.filter(
          emp => emp.projectAllocation > 0 && emp.allocation > 0
        );
        console.log(
          "this.selectedProjectEmployees",
          this.selectedProjectEmployees
        );

        this.upDateState(
          this.selectedProjectEmployees,
          selectedProjects[0].name
        );
      }
    }
    this.projects = resourceData.projects;
  }
  // callbackFunction(childDta) {
  //   this.setState({ message: childDta });
  // }

  componentDidMount() {
    console.log(this.state.message);
  }
  callbackFunction = childData => {
    this.setState({ message: childData });
  };
  handleClick = () => {
    console.log("Button is cliked!");
    this.setState({ referrer: "/employee/Child" });
  };
  //   <Redirect to={{
  //             pathname: '/order',
  //             state: { id: '123' }
  //         }}
  // />
  callbackFunction(childData) {
    this.setState({ message: childData });
  }
  render() {
    const { referrer } = this.state;
    // if (referrer)
    //   return (
    //     <Redirect
    //       to={{
    //         pathname: "/employee/Child",
    //         state: { name: "From Parent" },
    //         method: { m: "abc" }
    //       }}
    //     />
    //   );
    return (
      <div className="">
        {/* <div>
          <button type="button" onClick={this.handleClick}>
            GoChild
          </button>
          <div className="card">hi</div>
          <Child parentCallback={this.callbackFunction.bind(this)} />
          {this.state.message}
        </div> */}
        <div className="card-body view-port-height">
          <div className="row">
            <div className="col-3 thead-light font-weight-bold ">
              <label>Project Name : {this.state.projectName}</label>
            </div>
            <div className="col-3 ">
              <select
                className="form-control"
                onChange={this.onChangeOfProjectSelect}
                id="exampleFormControlSelect1"
              >
                <option>--Select Project--</option>
                {this.projects.map(project => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-3">
              <button
                type="button"
                className="btn btn-primary"
                onClick={this.onClickOfShowAllocation}
              >
                Show Allocation
              </button>
            </div>
            <div className="col-2 ">
              <button type="button" className="btn btn-secondory">
                <Link to={`${this.selectedProjectId}/employeeAdd`}>
                  Add Employee
                </Link>
              </button>
            </div>
            {/* <span className="col-1 statistic ">
              {" "}
              <Link to={`./employee/HighChart`}>Show Statistics</Link>
            </span> */}
          </div>

          <table className="table mt-3">
            <thead className="thead-light">
              <tr>
                <th scope="col">Employee Id</th>
                <th scope="col">Email Id</th>
                <th scope="col">Full Name</th>
                <th scope="col">Job Level</th>
                <th scope="col">Designation</th>
                <th scope="col">Allocation</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.selectedProjectEmployees.map((employee, index) => {
                return (
                  <tr key={index}>
                    <td> {employee.id}</td>
                    <td> {employee.emailId}</td>
                    <td> {employee.fullName}</td>
                    <td> {employee.jobLevel}</td>
                    <td> {employee.designation}</td>
                    <td> {employee.projectAllocation}%</td>
                    <td>
                      <Link
                        to={`${this.selectedProjectId}/employee/${employee.id}`}
                      >
                        Edit
                      </Link>
                    </td>
                  </tr>
                );
              })}

              {this.state.selectedProjectEmployees.length ? null : (
                <tr className="text-center">
                  <td colSpan="7">No data.</td>
                </tr>
              )}
            </tbody>
          </table>

        </div>
          <div className="card-body view-port-height">
            <Employee></Employee>
          </div>
        
      </div>
    );
  }
}

export default withRouter(EmployeeList);
