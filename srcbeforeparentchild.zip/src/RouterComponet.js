import React from "react";
import "./App.css";
import EmployeeList from "./employee/EmployeeList";
import Employee from "./employee/component/Employee";
import EmployeeAdd from "./employee/component/EmployeeAdd";
import HighChart from "./employee/HighChart";
// import Child from "./employee/Child";
import App from "./App";

import { Redirect } from "react-router";
import { Route } from "react-router";
import { BrowserRouter } from "react-router-dom";
function RouterComponet() {
  return (
    <BrowserRouter>
      <Route exact path="/" component={App} />
      <Route exact path="/:component/EmployeeList" component={EmployeeList} />

      <Route path="/:projectId/employeeAdd/" component={EmployeeAdd} />
      <Route path="/:projectId/employee/:id" component={Employee} />
      <Route path="/employee/HighChart/" component={HighChart} />
      {/* <Route path="/employee/Child/" component={Child} /> */}
    </BrowserRouter>
  );

};
export default RouterComponet
