import React from "react";
import "./App.css";
import EmployeeList from "./employee/EmployeeList";
import Employee from "./employee/component/Employee";
import EmployeeAdd from "./employee/component/EmployeeAdd";
import HighChart from "./employee/HighChart";
// import Child from "./employee/Child";
import { Redirect } from "react-router";
import { Route } from "react-router";
import { BrowserRouter } from "react-router-dom";
import RouterComponet from "./RouterComponet";
class App extends React.Component {
  constructor(props) {
    super(props);
  }
  goToEmployee() {}
  render() {
    return (
      <div className="container-fluid mt-2">
        <div className="card">
          <div className="card-header text-center font-weight-bolder">
            <span className="col-sm-2 ">Resource Allocation</span>
          </div>
          {/* <button type="button" onClick={this.goToEmployee.bind(this)}>
            goToEmployee
          </button> */}
          <div className="row">
            <nav
              className="
            navbar navbar-default col-sm-2
                    "
            >
              <ul className="nav navbar-nav">
                <li>
                  <a href="#">Dashboard</a>
                </li>
                <li>
                  <a href="#">Show Project</a>
                </li>
                <li>
                  <a href="#">Show Statistics</a>
                </li>
              </ul>
            </nav>
            <div className="container-fluid col-sm-10">
              <div className="card-body view-port-height">
                <div className="row"></div>
                {/* <EmployeeList></EmployeeList> */}
                <div className="main-content">
                  <Route
                    exact
                    path="/:component/EmployeeList"
                    component={EmployeeList}
                  />
                  {/* <Route exact path="/settings" component={SettingsComponet} /> */}
                </div>

                {/* <RouterComponet/> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
