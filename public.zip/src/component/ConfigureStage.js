import React from "react";
import Table from "./ReusableComponent/Table";
import DropDown from "./ReusableComponent/DropDown";

//Fetch data
const {
  Target,
  Source,
  headers,
  tableData
} = require("../component/Data/constantData.json");

class ConfigureStage extends React.Component {
  constructor() {
    super();
    this.state = {
      selectedOption: null
    };
  }

  getSelectedTargetValue = id => {
    this.setState({
      selectedOption: id.name
    });
  };

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-2 reactSelect">
            <label>Target 0/3</label>
            <i className="fa fa-eye" style={{ marginLeft: "51px" }}></i>

            <DropDown
              options={Target}
              getSelectedTargetValue={this.getSelectedTargetValue}
            ></DropDown>
          </div>
          <div className="col-sm-2 reactSelect">
            <label>Source(10) </label>
            <i className="fa fa-eye" style={{ marginLeft: "47px" }}></i>
            <DropDown
              options={Source}
              getSelectedTargetValue={this.getSelectedTargetValue}
            ></DropDown>
          </div>
          <div className="col-sm-3 ">
            <label>Target CDM Total </label>

            <table className="table table-bordered">
              <tbody>
                <tr>
                  <td>28</td>
                  <td>5</td>
                  <td>28</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="col-sm-3">
            <label>Mapped Auto Manual Unmap</label>

            <table className="table table-bordered">
              <tbody>
                <tr>
                  <td>18</td>
                  <td>10</td>
                  <td>8</td>
                  <td>8</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div>
            <button type="button  " class="btn btn-success btnHeight">
            Mark As Complete
            </button>
          </div>
        </div>
        <br></br>
        <div>
          <label>Field Mappings</label>
          <Table headers={headers} tableData={tableData}></Table>
        </div>
      </div>
    );
  }
}
export default ConfigureStage;
