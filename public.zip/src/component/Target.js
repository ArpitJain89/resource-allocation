import React from "react";
class Target extends React.Component {
  render() {
    return (
      <div>
        <h1 className=" text-center "> Target</h1>
      </div>
    );
  }
}
export default Target;
