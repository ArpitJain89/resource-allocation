import React from "react";
import Select from "react-select";

class DropDown extends React.Component {
  constructor() {
    super();
    this.state = {};
  }

  render() {
    const  options  = this.props.options;
    return (
      <div>
        <Select
          className="react-selectcomponent 
          "
          value={this.state.selectedOption}
          placeholder="Choose"
          onChange={id => {
            this.props.getSelectedTargetValue(id);
          }}
          getOptionLabel={option => `${option.name}`}
          options={options}
        />
      </div>
    );
  }
}
export default DropDown;
