import React from "react";

class Table extends React.Component {
  constructor(props) {
    super(props);
    this.getHeader = this.getHeader.bind(this);
    this.getRowsData = this.getRowsData.bind(this);
  }

  getHeader() {
    let columnHeader = this.props.headers;
    let res = [];
    for (var i = 0; i < columnHeader.length; i++) {
      res.push(<th key={columnHeader[i]}>{columnHeader[i]}</th>);
    }
    return res;
  }
  tableData;

  getRowsData() {
    let items = this.props.tableData;
    let keys = this.props.headers;
    return items.map((row, index) => {
      return (
        <tr key={index}>
          <RenderRow key={index} data={row} keys={keys} />
        </tr>
      );
    });
  }



  render() {
    return (
      <div>
        <div>
          <table className="table table-bordered ">
            <thead className="thead-light ">
              <tr>{this.getHeader()}</tr>
            </thead>
            <tbody>{this.getRowsData()}</tbody>
          </table>
        </div>
      </div>
    );
  }
}
export default Table;

const RenderRow = props => {
  return props.keys.map((key, index) => {
    return <td key={props.data[key]}>{props.data[key]}</td>;
  });
};
