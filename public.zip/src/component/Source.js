import React from "react";
class Source extends React.Component {
  render() {
    return (
      <div>
        <h1 className=" text-center "> Source</h1>
      </div>
    );
  }
}
export default Source;
