import React from "react";
class ValidateAndProcess extends React.Component {
  render() {
    return (
      <div>
        <h1 className=" text-center "> Validate And Process</h1>
      </div>
    );
  }
}
export default ValidateAndProcess;
