import React from "react";
class HistoricalSimilarities extends React.Component {
  render() {
    return (
      <div>
        <h1 className=" text-center "> Historical Similarities</h1>
       
        
      </div>
    );
  }
}
export default HistoricalSimilarities;
